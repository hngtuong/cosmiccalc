# `cosmiccalc` (originally stylized as CosmiCalc)

A web-based build simulator for a (now out-of-service) 3D MMOTPS [CosmicBreak](http://cosmicbreak.cyberstep.com).  
CyberStep has revealed the new version of the game called [Cosmic Break Universal](https://cosmicbreak-universal.com/).

**Note that we do not have up-to-date stats to fully support CBUNI currently.**  
Some low-effort updates might be made to make this simulator be slightly more helpful for CBUNI during the beta period.

## Contributing

Interested in helping us? [Read this to get started!](CONTRIBUTING.md)
